import java.util.List;
import java.util.Objects;

class Student
{
   private final String surname;
   private final String givenName;
   private final int age;
   private final List<CourseSection> currentCourses;

   public Student(final String surname, final String givenName, final int age,
      final List<CourseSection> currentCourses)
   {
      this.surname = surname;
      this.givenName = givenName;
      this.age = age;
      this.currentCourses = currentCourses;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null) {
         return false;
      }
      if (getClass() != o.getClass()) {
         return false;
      }
      Student s = (Student) o;
      return Objects.equals(surname, s.surname) && Objects.equals(givenName, s.givenName) &&
              Objects.equals(age, s.age) && Objects.equals(currentCourses, s.currentCourses);
   }

   public int hashcode() {
      int prime = 17;
      int result = 1;
      result = prime * result + ((surname == null) ? 0 : surname.hashCode());
      result = prime * result + ((givenName == null) ? 0 : givenName.hashCode());
      result = prime * result + age;
      return result;
   }
}
